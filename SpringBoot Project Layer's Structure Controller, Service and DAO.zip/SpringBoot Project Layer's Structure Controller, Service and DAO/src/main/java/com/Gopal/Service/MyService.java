package com.Gopal.Service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.Gopal.DAO.MyDAO;
import com.Gopal.Pojo.Student;

@Service
public class MyService {

	@Autowired
	private MyDAO myDAO;

	public String showSingleStudentRecord(int id) {
		return myDAO.showSingleStudentRecord(id);
	}

	public String showMultipleStudentRecord() {
		return myDAO.showMultipleStudentRecord();
	}

	public String insertSingleStudentRecord(Student student) {
		return myDAO.insertSingleStudentRecord(student);
	}

	public String insertAPI(int id, String name) {
		return myDAO.insertAPI(id, name);
	}

	public String insertMultipleStudentRecord(List<Student> list) {
		return myDAO.insertMultipleStudentRecord(list);
	}

	public String updateSingleStudentRecord(Student student) {
		return myDAO.updateSingleStudentRecord(student);
	}

	public String multipleupdate(List<Student> list) {
		return myDAO.multipleupdate(list);
	}

	public String partialSingleFieldUpdate(int id, String name) {
		return myDAO.partialSingleFieldUpdate(id, name);
	}

	public String partialMultipleFieldUpdate(int id, String name, String city) {
		return myDAO.partialMultipleFieldUpdate(id, name, city);
	}

	public String deleteSingleStudentRecord(int id) {
		return myDAO.deleteSingleStudentRecord(id);
	}

	public String deleteAllStudentRecord() {
		return myDAO.deleteAllStudentRecord();
	}

}
